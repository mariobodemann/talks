#include <stdio.h>
#include <errno.h>

int main(int argc, char** argv)
{
	float f = 3.1415926535897932384626433832795f;
	char pcString[256];

	printf("Values:\n");
	printf("a = %d\n", 12);
	printf("b = %f\n", 1.3f);
	printf("c = %s\n", "Hello");
	
	printf("\nValues, right-justified:\n");
	printf("a = %10d\n", 12);
	printf("b = %10f\n", 1.3f);
	printf("c = %10s\n", "Hello");

	printf("\nValues, right-justified, with padding:\n");
	printf("a = %010d\n", 12);
	printf("b = % 10f\n", 1.3f);
	printf("c = %010s\n", "Hello");
	
	printf("\nValues, left-justified(?):\n");
	printf("a = %-10d|Next\n", 12);
	printf("b = %-010f|Next\n", 1.3f);
	printf("c = %-010s|Next\n", "Hello");

	printf("\nFloats:\n");
	printf("PI = %f\n", f);
	printf("PI = %.0f\n", f);
	printf("PI = %.2f\n", f);
	printf("PI = %.9f\n", f);
	printf("1.95 ~= %.1f\n", 1.95f);

	printf("\nFloats, right-justified:\n");
	printf("PI = %12f\n", f);
	printf("PI = %12.2f\n", f);
	printf("PI = %012.9f\n", f);

	printf("\ncombined:\n");
	printf("PI = %12f| next\n", f);
	printf("PI = %12.2f| next\n", f);
	printf("PI = %012.7f| next\n", f);
	printf("PI = %-012.7f| next\n", f);
	
	printf("\nsprintf:\n");
	sprintf(pcString, "PI = %12.9f\n", 3.14f);
	printf("string=\"%s\"\n",pcString);

	fprintf(stdout, "\nSTDOUT-Test\n");		

	printf("\nInput\n");
	FILE* pDatei = fopen("test.dat","w");
	if( pDatei != NULL)
	{
		fprintf( pDatei, "HalloDatei" );
	}
	else
	{
		printf( "%s\n", strerror(errno) );
	}
	
	printf("two digits: ");
	fflush(stdout);
	
	int iFirst = 0;
	int iSecond = 0;
	int iRead = scanf("%d %d", &iFirst, &iSecond);
	
	if( iRead != 2)
	{
	  fprintf(stderr,"Error!\n");
	}
	else
	{
	  printf("%d + %d = %d\n", iFirst, iSecond, iFirst + iSecond);
	}

	printf("\nCSV\n");
	/* again: we want to read a file */
	FILE *pFile = fopen("./test.csv", "r");
	if( NULL == pFile){
		fprintf(stderr, "Cannot find file.\n");
		return -1;
	}
	/* read csv file */
	float a = 0.0f, b = 0.0f, c = 0.0f;
	int i = 0;
	/* loop till end of file is reached */
	do{
		i = fscanf( pFile, "%f, %f, %f\n",&a, &b, &c);
		if( i == 3){
			printf("%f + %f + %f = %-31.2f\n",a,b,c, a+b+c);
		}
		else
		{
			fprintf(stderr, "Read error (EOF?)\n");
		}
	}while( i == 3 );
	fclose(pFile);
	
	return 0;
}
