/**
 * Schiffe versenken by Mario Bodemann
 *
 * Dieses Programm wurde für den CKurs 2009 geschrieben. 
 * Kompilieren: gcc -std=c99 -o SchiffeVersenken SchiffeVersenken.c
 *
 * Ach, und herzlichen Glückwunsch: Du hast soebend ein Easteregg gefunden ... :-D
 * Von nun an sind alle Kommentare auf englisch!
 *
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h> // used for string functions (strlen)
#include <time.h> // used for time() [init of random]

//
// Global definitions
//

#define FIELD_WIDTH  24
#define FIELD_HEIGHT  12

#define SHIP_BIG_COUNT  5
#define SHIP_BIG_FIELDS 6

#define SHIP_MID_COUNT  10
#define SHIP_MID_FIELDS 4

#define SHIP_SMALL_COUNT  20
#define SHIP_SMALL_FIELDS 2

#define COLOR_BORDER_TEXT   47
#define COLOR_BORDER_COORDS 46
#define COLOR_BORDER        40
#define COLOR_WATER         44

#define COLOR_PLAYER_SHIP 40
#define COLOR_AI_SHIP     COLOR_WATER	
#define COLOR_SHIP_HIT    41

#define CHAR_WATER     '~'
#define CHAR_WATER_HIT 'o'
#define CHAR_SHIP      CHAR_WATER
#define CHAR_SHIP_HIT  ' '

#define WATER     0
#define WATER_HIT 1
#define SHIP      2
#define SHIP_HIT  3

// create all fields
unsigned char pucPlayerField[FIELD_WIDTH * FIELD_HEIGHT];
unsigned int iPlayerShipsLeft = 0;
unsigned char pucAIField[FIELD_WIDTH * FIELD_HEIGHT];
unsigned int iAIShipsLeft = 0; 

//
// Forward declarations
//
typedef int bool;
#define true 1
#define false 0

bool generateField(unsigned char* pucField);
bool askForField(unsigned char* pucField);
void drawFields(int iPlayerShipsLeft, int iAIShipsLeft);

bool askForAttack( unsigned char* pucOpponentField, unsigned int * piOpponedShipsLeft );
bool randomAttack( unsigned char* pucOpponentField, unsigned int * piOpponedShipsLeft );

//
// main function
// 
int main(int argc, char** argv)
{
	// reset random seed
	srand( time(NULL) );

	// create both fields
	generateField( pucAIField );
	generateField( pucPlayerField );

	// set ship count
	iPlayerShipsLeft = SHIP_BIG_COUNT * SHIP_BIG_FIELDS + 
				SHIP_MID_COUNT*SHIP_MID_FIELDS + 
				SHIP_SMALL_COUNT*SHIP_SMALL_FIELDS;

	iAIShipsLeft = SHIP_BIG_COUNT * SHIP_BIG_FIELDS + 
			SHIP_MID_COUNT*SHIP_MID_FIELDS + 
			SHIP_SMALL_COUNT*SHIP_SMALL_FIELDS;
	
	
	// start main loop 
	bool bGameOver = false;
	while( !bGameOver )
	{
		// render fields
		drawFields(iAIShipsLeft, iPlayerShipsLeft);			

		// shoot while only ships are hit
		while(!bGameOver && askForAttack(pucAIField, &iAIShipsLeft))
		{
			drawFields(iAIShipsLeft, iPlayerShipsLeft);			
		
			// update state		
			bGameOver = iAIShipsLeft <= 0 || iPlayerShipsLeft <= 0;
		}

		// let computer shoot till water are hit
		while( !bGameOver && randomAttack(pucPlayerField, &iPlayerShipsLeft))
		{
			// update
			bGameOver = iAIShipsLeft <= 0 || iPlayerShipsLeft <= 0;
		}
	}
	
	// output success
	drawFields(iAIShipsLeft, iPlayerShipsLeft);			
	printf("\n\n\n\t%s just have won the game!!\n\n\n", iAIShipsLeft <= 0 ? "\e[32mYou\e[m" : "\e[31mThe Computer\e[m");
}

//
// implementations
//

bool canShipBePlaced( unsigned char* pucField, unsigned int x, unsigned int y,  unsigned int iOffset, int iCount )
{
	// return value
	bool bPlaceable = true;
	
	// check for to big ship (end of field reached)
	if( iOffset == 1 ) // horizontal ship
	{
		bPlaceable = x + iCount < FIELD_WIDTH;
	}
	else // vertical ship
	{
		bPlaceable = y + iCount < FIELD_HEIGHT;
	} // if check field bounds

	// loop through field
	int iStartPosition = x+y*FIELD_WIDTH;
	for( int iPosition = iStartPosition; 
		iPosition < iStartPosition + iCount*iOffset && 
		bPlaceable == true; 
		iPosition += iOffset)
	{
		// is this field free?
		bPlaceable = ( pucField[ iPosition ] == WATER );
		
	} // loop through ship
	
	// return if ship is placeable
	return bPlaceable;
}

// places one ship in the field
void placeShip(unsigned char* pucField, unsigned int x, unsigned y, unsigned iOffset, unsigned iCount)
{
	// loop through all ship parts
	for( int i = 0; i < iCount; ++i)
	{
		pucField[ x + y*FIELD_WIDTH + i*iOffset ] = SHIP;
	}
}

bool askForShip( unsigned int* px, unsigned int* py, unsigned int* piOffset )
{
	// ask for start position
	printf("Please enter coordinates [abc xyz]   ");
	if( 2 != scanf("%d %d",px, py) )
	{
		printf("\e[31;7mCould not read your input! Please enter corrindates in format xxx, yyy.\e[m\n");
		printf("\n");
				
		char pcTest[255];
		scanf("%s",pcTest);
		return false;
	}
		
	// ask if vertical or horizontal
	printf("Should it be placed horizontal or vertical? [h|v]   ");
	char pch[256];
	if( 1 != scanf("%s",pch))
	{
		printf("\e[31;7mCould not read your input! Please enter either \"h\" or \"v\" instead of \"%s\".\e[m\n", pch);
		printf("\n");
		return false;
	}
	*piOffset = (pch[0] == 'h' ? 1 : FIELD_WIDTH);
	
	// done
	return true;
}

// asks the user to enter coordinates for the next ship
bool askForShips( unsigned char* pucField, unsigned int iShipCount, unsigned int iShipFields )
{
	// loop through all ships
	for ( int iShip = 0; iShip < iShipCount; ++iShip)
	{
		// draw user fields
		drawFields( iAIShipsLeft, iPlayerShipsLeft);
	
		// inform user
		printf("\nPlease enter ship %d/%d of size %d.\n", iShip+1, iShipCount, iShipFields);
	
		// set a max value for tries
		int x = 0;
		int y = 0;
		int iOffset = 0;
		bool bCanBePlaced = false;
	
		// loop till a place for this ship was found
		do {
			// ask user for ship placement
			if( !askForShip( &x, &y, &iOffset) )
			{
				// user input error
				continue;
			}

			// check if it can be placed
			bCanBePlaced = canShipBePlaced( pucField, x, y,  iOffset, iShipFields);
			if( !bCanBePlaced )
			{
				// inform user about his/her failure
				printf("\e[31;7mPlease set ship where it cannot intersect with other ships\n\t(Current ship at %d %d pointing %s[%d])...\e[m\n",
						x,y, iOffset == 1 ? "right" : "down", iOffset);
			}
			
			printf("\n\n");
			
		// loop if ship can not be placed (and it was tried less then w*h times!)
		} while ( !bCanBePlaced );	
		
		// place ship
		placeShip(pucField,x,y,iOffset, iShipFields);
		
	} // loop all ships
	
	// all ships were placed
	return true;
}

// ask user for input of field
bool askForField( unsigned char* pucField)
{
	// set field to zero
	for( int i = 0; i < FIELD_WIDTH*FIELD_HEIGHT; ++i)
	{
		pucField[i] = 0;
	}
	
	// set ships
	if( !askForShips( pucField, SHIP_BIG_COUNT, SHIP_BIG_FIELDS ) )
	{
		fprintf( stderr, "User could not place all big ship\n");
		return false;
	}

	// set ships
	if( !askForShips( pucField, SHIP_MID_COUNT, SHIP_MID_FIELDS ) )
	{
		fprintf( stderr, "User could not place all mid ship\n");
		return false;
	}
	// set ships
	if( !askForShips( pucField, SHIP_SMALL_COUNT, SHIP_SMALL_FIELDS ) )
	{
		fprintf( stderr, "User could not place all small ship\n");
		return false;
	}
	
	// done
	return true;
}

// place all ships of a given class
bool randomlyPlaceShips( unsigned char* pucField, unsigned int iShipCount, unsigned int iShipFields )
{
	// loop through all ships
	for ( int iShip = 0; iShip < iShipCount; ++iShip)
	{
		// set a max value for tries
		int iMaxTries = FIELD_WIDTH*FIELD_HEIGHT;
		
		int x = 0;
		int y = 0;
		int iOffset = 0;
	
		// loop till a place for this ship was found
		do {
			// create a random start position
			x = rand() % (FIELD_WIDTH);
			y = rand() % (FIELD_HEIGHT);
		
			// set offset (0 == vertical | FIELD_WIDTH == horizontal)
			iOffset = (rand() % 2 ) * FIELD_WIDTH;
		
			if( iOffset == 0) // vertical?
			{
				iOffset = 1;
			}
			
		// loop if ship can not be placed (and it was tried less then w*h times!)
		} while ( !canShipBePlaced( pucField, x, y,  iOffset, iShipFields) && --iMaxTries > 0);	
		
		// check if ship was placed
		if( iMaxTries <= 0)
		{
			// error occured!
			return false;
		}
		else
		{
			// place ship
			placeShip(pucField,x,y,iOffset, iShipFields);
		}
		
	} // loop all ships
	
	// all ships were placed
	return true;
}

// randomily generate a field
bool generateField( unsigned char* pucField)
{
	// set field to zero
	for( int i = 0; i < FIELD_WIDTH*FIELD_HEIGHT; ++i)
	{
		pucField[i] = 0;
	}
	
	// set ships
	if( !randomlyPlaceShips( pucField, SHIP_BIG_COUNT, SHIP_BIG_FIELDS ) )
	{
		fprintf( stderr, "Could not place all big ships!\n");
		return false;
	}

	if( !randomlyPlaceShips( pucField, SHIP_MID_COUNT, SHIP_MID_FIELDS ) )
	{
		fprintf( stderr, "Could not place all middle ships!\n");
		return false;
	}

	if( !randomlyPlaceShips( pucField, SHIP_SMALL_COUNT, SHIP_SMALL_FIELDS ) )
	{
		fprintf( stderr, "Could not place all small ships!\n");
		return false;
	}
	
	// done
	return true;
}

// draws one element colored
void drawElement( char cElement,  unsigned char cColor )
{
	printf("\e[%dm%c \e[m", cColor, cElement );
}
	
// draws one line from pucField
void drawLine( unsigned char* pucField, unsigned iStartY, unsigned char cShipColor, unsigned char cWaterColor)
{
	// draw line
	for ( int x = 0; x < FIELD_WIDTH; ++x)
	{
		// assign colors and chars
		char cElement;
		unsigned char cColor;
		switch( pucField[x + iStartY*FIELD_WIDTH] )
		{
		case WATER:
			cColor = COLOR_WATER;
			cElement = CHAR_WATER;
			break;
		case WATER_HIT:
			cColor = COLOR_WATER;
			cElement = CHAR_WATER_HIT;
			break;
		case SHIP:
			cColor = cShipColor;
			cElement = CHAR_SHIP;
			break;
		case SHIP_HIT:
			cColor = COLOR_SHIP_HIT;
			cElement = CHAR_SHIP_HIT;
			break;
		default:
			cColor = 46;
			cElement = '?';
			break;
		}
	
		// draw ship or water
		drawElement( cElement, cColor );
	}
}

void drawSolidLine(unsigned int iWidth, unsigned char cBorderColor, unsigned char cBorderTextColor, const char* pcText )
{
	// start of text
	int iTextLen = strlen( pcText );
	int iTextStart = iWidth / 2 - iTextLen / 2;

	// loop through field
	for( int i = 0; i < iWidth; ++i)
	{
		// draw centered text
		if( i >= iTextStart && i < iTextStart + iTextLen)
		{
			drawElement( pcText[i-iTextStart], cBorderTextColor );
		}
		else if( i+1 == iTextStart || i == iTextStart+iTextLen)
		{
			drawElement( ' ', cBorderTextColor);
		}
		else
		{
			drawElement( ' ', cBorderColor);
		}
	}
}

void drawEmptyFieldLine(const char* pcPlayerString, const char* pcAIString)
{
	drawElement(' ', 0);
	drawSolidLine( FIELD_WIDTH, COLOR_BORDER, COLOR_BORDER_TEXT, pcPlayerString );
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawSolidLine( FIELD_WIDTH, COLOR_BORDER, COLOR_BORDER_TEXT, pcAIString );
	printf("\n");
}

void drawColumnNumbers()
{
	drawElement(' ', COLOR_BORDER);
	for( int i = 0; i < FIELD_WIDTH; ++i)
		drawElement( '0' + (i%10), COLOR_BORDER_COORDS );
	drawElement(' ', COLOR_BORDER);

	drawElement(' ', 0);
	drawElement(' ', 0);
	drawElement(' ', 0);

	drawElement(' ', COLOR_BORDER);
	for( int i = 0; i < FIELD_WIDTH; ++i)
		drawElement( '0' + (i%10), COLOR_BORDER_COORDS );
	drawElement(' ', COLOR_BORDER);
		
	// draw a new line
	printf("\n");
}

void drawFields(int iAIShipsLeft, int iPlayerShipsLeft)
{
	// draw top border
	drawElement(' ', 0);
	drawEmptyFieldLine( "Your Fleet", "AI Fleet" );
	
	// draw numbers
	drawElement(' ', 0);
	drawColumnNumbers();
	
	// loop through field (horizontally)
	for ( int y = 0; y < FIELD_HEIGHT; ++y )
	{
		// draw border	
		drawElement(' ', COLOR_BORDER);
		drawElement('0' + (y%10), COLOR_BORDER_COORDS);

		// draw player fields line
		drawLine( pucPlayerField, y, COLOR_PLAYER_SHIP, COLOR_WATER );
		drawElement('0' + (y%10), COLOR_BORDER_COORDS);
		drawElement(' ', COLOR_BORDER);

		// draw spacer between two fields
		drawElement(' ', 0);

		// draw ai line
		drawElement(' ', COLOR_BORDER);
		drawElement('0' + (y%10), COLOR_BORDER_COORDS);
		drawLine( pucAIField, y, COLOR_AI_SHIP, COLOR_WATER );
		drawElement('0' + (y%10), COLOR_BORDER_COORDS);
		drawElement(' ', COLOR_BORDER);
		printf("\n");
	}
	
	// draw numbers
	drawElement(' ', 0);
	drawColumnNumbers();

	// draw a border line
	drawElement(' ', 0);
	drawSolidLine( FIELD_WIDTH+2, COLOR_BORDER, COLOR_BORDER, "" );
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawSolidLine( FIELD_WIDTH+2, COLOR_BORDER, COLOR_BORDER, "" );
	printf("\n");

	// draw top border
	char pcPlayerShipsLeft[64];
	sprintf( pcPlayerShipsLeft, "ShipsLeft: % 3d", iPlayerShipsLeft);
	char pcAIShipsLeft[64];
	sprintf( pcAIShipsLeft, "ShipsLeft: % 3d", iAIShipsLeft);
	drawElement(' ', 0);
	drawEmptyFieldLine( pcPlayerShipsLeft, pcAIShipsLeft );
	
	// draw a border line
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawSolidLine( FIELD_WIDTH, COLOR_BORDER, COLOR_BORDER, "" );
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawElement(' ', 0);
	drawSolidLine( FIELD_WIDTH, COLOR_BORDER, COLOR_BORDER, "" );
	printf("\n");

}

bool hitField( unsigned char* pucField, unsigned int x, unsigned int y, unsigned int* piShipsLeft )
{
	// was a ship hit?
	bool bHit = false;
	
	switch( pucField[x + y*FIELD_WIDTH] )
	{
	case WATER:
	case WATER_HIT:
		pucField[x+y*FIELD_WIDTH] = WATER_HIT;
		break;
	case SHIP:
		(*piShipsLeft) --;
		bHit = true; // ship was hit
	case SHIP_HIT:
		pucField[x+y*FIELD_WIDTH] = SHIP_HIT;
		break;
	}
	
	return bHit;
}	

bool randomAttack( unsigned char* pucOpponentField, unsigned int* piShipsLeft )
{
	// let ai choose a random point
	int x = rand() % FIELD_WIDTH;
	int y = rand() % FIELD_HEIGHT;
	
	// check if already hit
	while( pucOpponentField[x + y*FIELD_WIDTH] == WATER_HIT ||
		pucOpponentField[x +y*FIELD_WIDTH] == SHIP_HIT )
	{
		x = rand() % FIELD_WIDTH;
		y = rand() % FIELD_HEIGHT;
	}
	
	// output action
	printf("\nRandomshoot to % 3dx% 3d.\n\n", x,y);
	
	// place it
	return hitField( pucOpponentField, x, y, piShipsLeft );
}

// let the user choose a field to be attacked
bool askForAttack( unsigned char* pucOpponentField, unsigned int* piShipsLeft )
{
	// let ai choose a random point
	int x = -1;
	int y = -1;
	int iElemsRead = 0;
	
	// loop till user entered coordinates (inside field and correctly formated)
	do
	{
		// read input
		printf("Please enter coordinates to shoot at: [abc xyz]   ");
		iElemsRead = scanf("%d %d",&x, &y);
		
		// check for field bounds
		if( x < 0 || y < 0 || x >= FIELD_WIDTH || y >= FIELD_HEIGHT) 
		{
			printf("\e[31;7mThis attack is outside of field! Please retry.\e[m\n");
		}
		if( 2 != iElemsRead )// no two values added
		{
			printf("\e[31;7mCould not read your input! Please enter corrindates in format xxx, yyy!\e[m\n");
			char pcTemp[256];
			scanf("%s", pcTemp);
		}		
	}
	while( 2 != iElemsRead || (x < 0 || y < 0 || x >= FIELD_WIDTH || y >= FIELD_HEIGHT) );

	// enter it to field
	return hitField( pucOpponentField, x, y, piShipsLeft );
}
