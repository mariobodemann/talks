//
// Samples from c-course 2010 for printf/scanf slides by Mario Bodemann
//

// sample includes
#include <stdio.h>
#include <string.h>
#include <errno.h>

// main function
int main(int argc, char** argv)
{
	int a = 4;
	int b = 4 + a;
	int c = ++b + a++;
	int d = (a == b ? c : --b + c);

	if( 9 == d )
	{
		d %= 8;
	} 
	else 
	{
		d <<= 2;
	}

	// this code will print all variables
	printf("a= %d\n", a);
	printf("b= %d\n", b);
	printf("c= %d\n", c);
	printf("d= %d\n", d);

  	// end
	return 0;
}

