//
// Samples from c-course 2010 for printf/scanf slides by Mario Bodemann
//

// sample includes
#include <stdio.h>
#include <string.h>
#include <errno.h>

// main function
int main(int argc, char** argv)
{
	// output to string
	char pc[255];
	sprintf(pc, "PI = %12.9f", 3.14f);

	printf("Inhalt von pc: \"%30s\"\n", pc);
}

