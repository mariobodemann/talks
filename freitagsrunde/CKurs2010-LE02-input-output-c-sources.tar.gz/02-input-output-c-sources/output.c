//
// Samples from c-course 2010 for printf/scanf slides by Mario Bodemann
//

// sample includes
#include <stdio.h>
#include <string.h>
#include <errno.h>

// main function
int main(int argc, char** argv)
{
	// example output
	printf("      Name | Anzahl |      Gewicht\n");
	printf(" ----------+--------+-------------\n");
	printf(" %s | %d | %f\n", "Samus", 12, 2.718 ); 
	printf(" %9s | %6d | %12f\n", "Tails", 1, 1.0 );
	printf(" %09s | %06d | %012f\n", "Toad", 43, 31.33 ); 
	printf(" %-9s | %-6d | %-12f\n", "GLaDOS", 87, 3.14 );
	printf(" %9s | %6d | %12.1f\n", "Kerrigan", 3, -0.16 );

	return 0;
}

