//
// Samples from c-course 2010 for printf/scanf slides by Mario Bodemann
//

// sample includes
#include <stdio.h>
#include <string.h>
#include <errno.h>

// main function
int main(int argc, char** argv)
{
	// open a file
	FILE *pFile = fopen("./test.dat", "w");

	// check for errors
	if( NULL == pFile )
	{
		// error handling ...
		fprintf(stderr,"Konnte Datei nicht finden ...\n");
		return -1;
	}

	// write something to a file
	fprintf(pFile, "HelloFile, %10.1f\n", 3.14f);

	// now close it again
	fclose(pFile);
}

