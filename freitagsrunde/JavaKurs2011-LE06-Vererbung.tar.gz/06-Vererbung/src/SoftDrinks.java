/**
 * Sample class for inheritance containing main-method
 */
public class SoftDrinks {
	public static void main(String[] args) {
		// create a mate to show super in methods
		MateDrink mate = new MateDrink(); 
		mate.drink();

		ColaDrink cola = new ColaDrink();
		cola.setVolume( 1.0 );
		cola.setName( "Buzz Cola" );
		System.out.println( "Name: " + cola.getName());
		cola.drink();

		// output two objects
		System.out.println( mate );
		System.out.println( cola );

		// check for equality
		if( (Object)mate == (Object)cola ) {
			System.out.println("Mate and Cola are the same!");
		} else {
			System.out.println("Indeed, Mate and Cola are different!");
		}

		// check for equality of two mates
		MateDrink yourMate = new MateDrink();
		if( mate == yourMate ) {
			System.out.println("Your and mine mate are the same!");
		} else {
			System.out.println("Arrr, you have an other mate than me.");
		}

		// reference vs. value comparison
		if( mate.equals(yourMate) == true ) {
			System.out.println("Our mate soft drinks are the same");
		} else {
			System.out.println("We do have different mate drinks!");
		}
	}
}

/**
 * Cola like soft drink
 */
class ColaDrink extends SoftDrink {
	public void drink() {
		System.out.println("You just drank a tasty cola drink!");
	}
}

/**
 * Fruit drink develloped in germany in mid 20th century
 */
class FruitDrink extends SoftDrink {
	public void drink() {
		System.out.println("Now you feel refreshed by a fruity drink.");
	}
}

/**
 * A drink which will empower you to code the whole night
 */
class MateDrink extends SoftDrink {
	public void drink() {
		super.drink();
		System.out.println( "You are now filled with powerfull energy!" );
	}
	public String toString() {
		return super.toString() + " (of powerfull energy)";
	}
}

/**
 * Baseclass for all soft drinks
 */
class SoftDrink {
	private double volume;
	private String name;
	
	public SoftDrink() {
		this.volume = 0.0;
		this.name = "Default Drink";
	}
	
	public double getVolume() {
		return this.volume;
	}
		 
	public void setVolume(double newVolume) {
		if( newVolume >= 0.0 ) {
			this.volume = newVolume;
		}
	}
	 
	public String getName() {
		return this.name;
	}
	
	public void setName(String newName) {
		this.name = newName;
	}
	
	public String toString() {
		return "Softdrink named " + this.name + ", holding " + this.volume + "l.";
	}
	
	public void drink() {
		System.out.println("You just drank a default drink!");
	}
	
	public boolean equals(Object other) {
		if( other instanceof SoftDrink ) {
			SoftDrink otherDrink = (SoftDrink)other;
			return otherDrink.getName().equals(this.getName()) && 
				otherDrink.getVolume() == this.getVolume();
		} else {
			return false;
		}
	}
}
