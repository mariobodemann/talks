/**
 * Samplefile for javacourse 2011 - a template, please remove me!
 *
 * Compile with "javac HelloWorld.java" or "make source" (if downloaded with tex source)
 */
public class HelloWorld {
	//! Main method get invoked once the class is loaded and found
	public static void main(String[] arguments) {
		// print default greeting and exit
		System.out.println("HelloWorld");
	}
}
