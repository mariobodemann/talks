/**
 * Class for recap of OOP 1 talk
 */
public class Human{
	private String name;
	private int age;

	public Human(){
		this.name = "";
		this.age  = 0;
	}

	public Human(String name, int age){
		setName(name);
		setAge(age);
	}

	public void setName( String newName ) {
		if( !newName.equals( "" ) ) {
			this.name = newName;
		}
	}

	public void setAge( int newAge ) {
		// check if age is in range
		if( newAge >= 0 && newAge < 130 ) {
			this.age = newAge;
		}
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getAge() {
		return this.age;
	}

	public String toString() {
		return "Human \"" + this.name + "\" is " + this.age + " years old.";
	}
	
	public boolean equals(Object o) {
		if( o instanceof Human ) {
			Human h = (Human)o;
			return h.getName().equals(this.getName()) && 
				h.getAge() == this.getAge();
		} else {
			return false;
		}
	}

	public static void main(String[] args){
		// create moe
		Human moe = new Human();
		moe.age = -12;
		moe.setAge( -12 );
		
		// create lenny and carl
		Human lenny = new Human("Lenny Leonard", 27);
		Human carl = new Human("Carl Carlson", 26);
		
		// print them
		System.out.println( lenny );
		System.out.println( carl );
			
		// compare carl and lenny
		if( carl == lenny ) {
			System.out.println("Lenny: \"I don't know where Carl ends and I begin!\"");
		} else {
			System.out.println("Carl: \"Aw, nuts. I mean... aw, nuts.\"");
		}
		System.out.println();
		
		// create a new carl to compare both
		Human carl2 = new Human("Carl Carlson", 26);
		if( carl == carl2 ) {
			System.out.println("Both Carls are equal");
		} else {
			System.out.println("carl and carl2 are not equal");
		}
		System.out.println();

		// use .equal to compare them
		if( carl.equals(carl2) ) {
			System.out.println(".equals reports both carls are equal");
		} else {
			System.out.println("carl is inequal to carl2");
		}
		System.out.println();
	}
}
