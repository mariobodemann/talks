public class HelloSolarSystem {

        public static void main(String[] args) {

                System.out.println("Hello Mercury!");
                System.out.println("Hello Venus!");
                System.out.println("Hello Earth!");
                System.out.println("Hello Mars!");
                System.out.println("Hello Jupiter!");
                System.out.println("Hello Saturn!");
                System.out.println("Hello Uranus!");
                System.out.println("Hello Neptune!");

        }

}
