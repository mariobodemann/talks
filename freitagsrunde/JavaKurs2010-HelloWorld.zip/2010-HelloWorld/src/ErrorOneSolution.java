public class ErrorOneSolution {
	public static void main(String[] argv) {
		System.out.println("Hello World");
	}
}
