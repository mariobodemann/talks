public class VariablesIV {
    public static void main(String[] args) {

       boolean amISmart = true;
       boolean amIAJavaHacker = false;

       boolean result = amISmart && amIAJavaHacker;

       String message = "Am I a smart Java hacker? ";
       System.out.println(message + result);
    }
}


