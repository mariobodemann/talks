/*
 Mehrzeiliger Kommentar
 */
public class Test {
	//! Einzeiliger JDoc Kommentar!
	public static void main(String[] argv) {
		// Gib etwas aus <- einzeiliger Kommentar
		int a = 4;
		String s = "string"+a;
		if( true ) {
			System.out.println(s);
		}	
	}
}
