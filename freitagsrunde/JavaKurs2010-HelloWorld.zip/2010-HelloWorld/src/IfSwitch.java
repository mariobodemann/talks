public class IfSwitch {
	public static void main(String[] argv){
		int number = 51231;
		
		System.out.print("Zahl endet auf ");
		switch( number % 10 ) {
			case 0:	System.out.println("Null");
				break;
			case 1: System.out.println("Eins");
				break;
			// ...
			default: System.out.println("Fehler!");
		}
	}
}
