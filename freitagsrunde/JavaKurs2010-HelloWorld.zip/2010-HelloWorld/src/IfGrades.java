public class IfGrades {
	public static void main(String[] argv){

		int points = 77;
		if( points <= 50 ) {
			System.out.println("Leider nicht bestanden ...");
		} else {
			System.out.println("Bestanden !!");
		}
		
	}
}
