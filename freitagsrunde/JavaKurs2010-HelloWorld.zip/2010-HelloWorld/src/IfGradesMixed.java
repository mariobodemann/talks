public class IfGradesMixed {
	public static void main(String[] argv){
	
		boolean testPassed = true;
		int points = 35;
		
		if( points > 50 && testPassed ) {
			System.out.println("Klausur bestanden!");
		} else {
		
			if( testPassed ) {
				System.out.println("Klausur wiederholen");
			} else {
				System.out.println("Durchgefallen ...");
			}
		}
	}
}
