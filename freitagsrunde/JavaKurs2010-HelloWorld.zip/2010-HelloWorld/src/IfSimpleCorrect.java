public class IfSimpleCorrect {
	public static void main(String[] argv){
	
		boolean catDown = true;
		if( catDown == true ) {
			System.out.println("Toast wird Katze drehen ...");
		} else {
			System.out.println("Katze wird Toast drehen ...");
		}
		
	}
}
