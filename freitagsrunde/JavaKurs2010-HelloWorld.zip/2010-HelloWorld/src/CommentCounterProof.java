public class CommentCounterProof { public static void main(String argv[]){ System.out.println("Not a good Example"); }}
