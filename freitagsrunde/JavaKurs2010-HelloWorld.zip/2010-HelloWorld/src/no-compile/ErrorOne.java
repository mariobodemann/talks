public class ErrorOne {
	public static void main(String[] argv) {
		System.out.println("Hello World")
	}
}
