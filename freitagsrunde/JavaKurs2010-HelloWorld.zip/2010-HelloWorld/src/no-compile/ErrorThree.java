public class ErrorThree {
	public static void main(String[] argv) {
		int dayOfWeek = 1;
		switch(dayOfWeek) {
			case 1:
				String dayName = "Monday";
			break;
			// ... 
		}
		System.out.println("Weekday = " + dayName);
	}
}
