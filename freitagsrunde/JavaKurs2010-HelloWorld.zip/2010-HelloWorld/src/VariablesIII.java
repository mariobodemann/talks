public class VariablesIII {
    public static void main(String[] args) {

       double height = 1.75;
       String message = "My height is ";
       System.out.println(message + height);
    
    }
}


