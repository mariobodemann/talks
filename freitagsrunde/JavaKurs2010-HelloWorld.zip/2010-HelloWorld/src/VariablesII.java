public class VariablesII {
    public static void main(String[] args) {

       int age = 20;
       int number = 3;

       age = age + number;
       String message;
       message = "My age is: ";


       System.out.println(message + age);

    }

}


