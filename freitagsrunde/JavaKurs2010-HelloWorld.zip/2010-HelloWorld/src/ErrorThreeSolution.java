public class ErrorThreeSolution {
	public static void main(String[] argv) {
		int dayOfWeek = 1;
		String dayName = "";
		switch(dayOfWeek) {
			case 1:
				dayName = "Monday";
			break;
			// ...
		}
		System.out.println("Weekday = " + dayName);
	}
}
