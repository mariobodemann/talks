/*
  Samplecode for "correct" commenting.
  
  This code will demonstrate how to use comments,
  either in a multiline fasion(like this one), or 
  by single line
 */
public class CommentedCounterProof { 
	// main entry point of class
	public static void main(String argv[]){ 
		// Supply our user with some basic
		// information about this sample.
		System.out.println("A better Example"); 
	}
} // done with this sample
