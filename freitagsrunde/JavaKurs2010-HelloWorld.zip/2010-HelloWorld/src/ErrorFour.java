public class ErrorFour {
	public static void main(String[] argv) {
		System.out.println( 1 / 0 );
	}
}
