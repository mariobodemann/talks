public class ErrorTwoSolution {
	public static void main(String[] argv) {
		int solution = 3 + 5;
		System.out.println("3 + 5 =" + solution);
	}
}
