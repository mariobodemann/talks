public class ErrorSpecialSolution {
	public static void main(String[] argv) {
		if(true) {
			System.out.println("Wahre Aussage");
		} else {
			System.out.println("Falsche Aussage");
		} // <--- inserted bracked
	}
}
