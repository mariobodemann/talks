public class Operators {
    public static void main(String[] args) {

       int a, b;
       a = 10;
       b = 2;

       int multi = a * b;
       int average = (a + b) / 2;

    }
}


