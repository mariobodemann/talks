public class Variables {
        public static void main(String[] args) {

               // Deklaration einer Variablen
               int number;
               // Initialisierung einer Variablen
               number = 23;
               System.out.println(number);

        }
}


