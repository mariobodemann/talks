//
// Samples from c-course 2010 for printf/scanf slides by Mario Bodemann
//

// sample includes
#include <stdio.h>
#include <string.h>
#include <errno.h>

// main function
int main(int argc, char** argv)
{
	int a = 0;
	int b = 0;
	int iValues = scanf("%d %d", &a, &b);
	printf("a + b = %d\n", a+b);
	printf("iValues = %d\n", iValues);
	
	return 0;
}

