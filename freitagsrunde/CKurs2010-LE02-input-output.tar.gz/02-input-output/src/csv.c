/**
 * This file will be used as a demonstration of
 * reading and writing to files.
 *
 * It will save be able to load and save a simple
 * example of csv files.
 *
 */
 
#include <stdio.h>
#include <string.h>

/**
 * Main function, opening a file, reading it, saving sth. in addtion
 */
int main(int argc, char** argv)
{
	//
	// 1: try to open file in read/write + append
	//
	FILE* pFile = fopen("./test.csv", "a+");

	//	
	// 2: check file
	//
	if( pFile == NULL )
	{
		fprintf(stderr, "Could not open file for writing\n");
		return -1;
	}

	//	
	// 3: access file
	//

	// print file content
	int iItemsRead = 0;

	// space for read items
	char  pcName[255];
	int   iAmount = 0;
	float fWeight = 0;

	// print header
	printf("%12s | %12s | %12s\n","Name","Anzahl","Gewicht" );
	printf("-------------+--------------+-------------\n" );
	do
	{
		// read values
		iItemsRead = fscanf(pFile, "%[A-Za-z]; %d; %f; ", &pcName, &iAmount, &fWeight );
	
		// check values read
		if( iItemsRead == 3 )
		{
			printf("%12s | %12d | %012.3f\n", pcName, iAmount, fWeight );
		}
	} while( iItemsRead == 3 );

	// add content?
	int iAgain = 1;
	while(iAgain)
	{		
		// ask user
		printf("Neuer Eintrag (0/1)? ");
		if( 1 != scanf("%d", &iAgain ) || iAgain == 0)
		{
			break;
		}

		// read all userdata needed
		printf("Name: ");
		if( 1 != scanf("%s", &pcName) )
		{
			fprintf(stderr, "Konnte Namen nicht lesen\n");
			continue;
		}
	
		printf("Anzahl: ");
		if( 1 != scanf("%d", &iAmount) )
		{
			fprintf(stderr, "Konnte Anzahl nicht lesen\n");
			scanf("%s", &pcName);
			continue;
		}

		printf("Gewicht: ");
		if(1 != scanf("%f", &fWeight) )
		{
			fprintf(stderr, "Konnte Gewicht nicht lesen\n");
			scanf("%s", &pcName);
			continue;
		}

		// everything read successfully
		int iCharsWritten = fprintf( pFile, "%s; %d; %f;\n", pcName, iAmount, fWeight );
		if(iCharsWritten <= 0)
		{
			fprintf(stderr, "Konnte Daten nicht schreiben!\n");
		}
	}

	//
	// 4: close file
	//
	fclose( pFile );

	// done
	return 0;
}

