//
// Samples from c-course 2010 for printf/scanf slides by Mario Bodemann
//

// sample includes
#include <stdio.h>
#include <string.h>
#include <errno.h>

// main function
int main(int argc, char** argv)
{
	// sample code
	float f = 3.1415926535897932384626433832795f;
	printf("PI = %12f | \n", f);
	printf("PI = %12.2f | \n", f);
	printf("PI = %012.7f | \n", f);
	printf("PI = %-012.7f | \n", f);
	
	return 0;
}

